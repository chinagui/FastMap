--whenever sqlerror exit failure
--whenever oserror exit failure
set echo   off
set timing on
set doc off
@@common_tables_create.sql
@@bit_util.pck
@@pipeline_utils.pck
@@pipeline_sdo.pck
@@pipeline_schema_utils.pck
@@bit_operations_util.pck
@@validation_create.sql
@@common_util.pck