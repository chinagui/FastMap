whenever sqlerror continue;
drop table NI_MESHLIST cascade constraints;
drop table NI_MESHLIST_100W cascade constraints;
drop table NI_MESHLIST_20W cascade constraints;
drop table NI_CONCAT_BORDER_RD_LINK cascade constraints;
drop table NI_LINK_NODE_EXT cascade constraints;
drop table NI_SHAPEPOINT cascade constraints;
drop table NI_LINK_POLYGON cascade constraints;
drop table NI_CROSS_ALINK cascade constraints;
drop table NI_CRF_LINK cascade constraints;
drop table NI_BORDERLINK cascade constraints;
drop table NI_RD_LINESEG cascade constraints;
drop table NI_RW_LINESEG cascade constraints;
drop table NI_AD_LINESEG cascade constraints;
drop table NI_ZONE_LINESEG cascade constraints;
drop table NI_LU_LINESEG cascade constraints;
drop table NI_LC_LINESEG cascade constraints;
drop table NI_CMBUILD_LINESEG cascade constraints;
drop table NI_CMBLOCK_LINESEG cascade constraints;
drop table NI_CMROAD_LINESEG cascade constraints;
drop table NI_CONCAT_ONROAD_NODE CASCADE CONSTRAINTS;
drop table NI_CONCAT_BORDER_RD_LINK_EXT;
drop table NI_RTIC_LINK cascade constraints;
DROP TABLE NI_LLR_LINK cascade constraints;
drop table SHD_BDYINTERSECT_LINK cascade constraints;
drop table ni_tmc_link cascade constraints;
DROP TABLE NI_LINK_LINK CASCADE CONSTRAINTS; 
drop table NI_LINK_FORM cascade constraints;
drop table NI_RTIC_LINK_LINK cascade constraints;
drop table NI_MESH_GRID cascade constraints;
drop table SHD_IN_BUFFER_LINK cascade constraints;
drop table SHD_PARK_LINK   cascade constraints;
drop table NI_NODE_FORM cascade constraints;
drop table NI_UTURN_LINK cascade constraints;
drop table NI_CROSS_LINK_LINK cascade constraints;
drop table NN_LINK cascade constraints;
drop table NI_MAINSIDE_LINK_LINK cascade constraints;
DROP TABLE NI_ZONE_KIND cascade constraints;
drop table NI_CONN_CKRESULT cascade constraints;
drop table NI_ADMIN_MESH cascade constraints;
drop table NI_CONN_DELREC cascade constraints;
drop table NI_CROSS_INNERLINK cascade constraints;
drop table SHD_PT_PT_DISTANCE cascade constraints;

whenever sqlerror exit failure;
create table NI_MESHLIST
(
  MESH_STR    VARCHAR2(6),
  MESH_ID     NUMBER(6) not null,
  LEFTBOTTOMX NUMBER(10,5),
  LEFTBOTTOMY NUMBER(10,5),
  RIGHTUPPERX NUMBER(10,5),
  RIGHTUPPERY NUMBER(10,5),
  ADMESH_ID_1 NUMBER(6),
  ADMESH_ID_2 NUMBER(6),
  ADMESH_ID_3 NUMBER(6),
  ADMESH_ID_4 NUMBER(6),
  ADMESH_ID_6 NUMBER(6),
  ADMESH_ID_7 NUMBER(6),
  ADMESH_ID_8 NUMBER(6),
  ADMESH_ID_9 NUMBER(6),
  GEOMETRY    SDO_GEOMETRY,
  primary key(MESH_ID)
);

create table NI_MESHLIST_20W
(
  MESH_STR    VARCHAR2(6),
  MESH_ID     NUMBER(6) not null,
  LEFTBOTTOMX NUMBER(10,5),
  LEFTBOTTOMY NUMBER(10,5),
  RIGHTUPPERX NUMBER(10,5),
  RIGHTUPPERY NUMBER(10,5),
  ADMESH_ID_1 NUMBER(6),
  ADMESH_ID_2 NUMBER(6),
  ADMESH_ID_3 NUMBER(6),
  ADMESH_ID_4 NUMBER(6),
  ADMESH_ID_6 NUMBER(6),
  ADMESH_ID_7 NUMBER(6),
  ADMESH_ID_8 NUMBER(6),
  ADMESH_ID_9 NUMBER(6),
  GEOMETRY    MDSYS.SDO_GEOMETRY,
  primary key(MESH_ID)
);

create table NI_MESHLIST_100W
(
  MESH_STR    VARCHAR2(6),
  MESH_ID     NUMBER(6) not null,
  LEFTBOTTOMX NUMBER(10,5),
  LEFTBOTTOMY NUMBER(10,5),
  RIGHTUPPERX NUMBER(10,5),
  RIGHTUPPERY NUMBER(10,5),
  ADMESH_ID_1 NUMBER(6),
  ADMESH_ID_2 NUMBER(6),
  ADMESH_ID_3 NUMBER(6),
  ADMESH_ID_4 NUMBER(6),
  ADMESH_ID_6 NUMBER(6),
  ADMESH_ID_7 NUMBER(6),
  ADMESH_ID_8 NUMBER(6),
  ADMESH_ID_9 NUMBER(6),
  GEOMETRY    MDSYS.SDO_GEOMETRY,
  primary key(MESH_ID)
);

/*==============================================================*/
/* Table: NI_CONCAT_BORDER_RD_LINK                              */
/* ���нӱ߹�ϵ�ı�   ����LINK�ӱ߼��                          */
/*==============================================================*/
create table NI_CONCAT_BORDER_RD_LINK
(
  master_id number(10),
  slave_id number(10),
  primary key (master_id,slave_id)
);

/*==============================================================*/
/* Table: NI_CONCAT_BORDER_RD_LINK_EXT                          */
/* ���нӱ߹�ϵ�ı�                                             */
/*==============================================================*/
create table NI_CONCAT_BORDER_RD_LINK_EXT 
(
  master_id number(10),
  slave_id number(10),
  primary key (master_id,slave_id)
);

create table NI_LINK_NODE_EXT
(
  LINK_ID      NUMBER(10) not null,
  NODE_ID      NUMBER(10) not null,
  LENGTH			 NUMBER(8,2),
  GEOMETRY     SDO_GEOMETRY,
  primary key (LINK_ID, NODE_ID)
);

create table NI_SHAPEPOINT
(
  LINK_PID     NUMBER(10) not null,
  TABLENAME    VARCHAR2(20) not null,
  SHAPE_SEQ    NUMBER(10) not null,
  XLONG        NUMBER,
  YLAT         NUMBER,
  Z_LEVEL      INTEGER,  
  IS_NODE      VARCHAR2(1),
  NODE_PID      NUMBER(10),
  SHAPE_COUNT  NUMBER(10),
  NHORIANGLE  NUMBER(4,1), 
  constraint   NI_SHAPEPOINT_PK primary key (tablename,link_pid, shape_seq)
);
ALTER TABLE NI_SHAPEPOINT NOLOGGING;
CREATE INDEX IDX_NI_SHAPEPOINT_X ON NI_SHAPEPOINT(XLONG) PARALLEL;
CREATE INDEX IDX_NI_SHAPEPOINT_Y ON NI_SHAPEPOINT(YLAT) PARALLEL;



/*==============================================================*/
/* Table: NI_CROSS_ALINK                                        */
/*==============================================================*/
CREATE TABLE NI_CROSS_ALINK
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL,
    PRIMARY KEY(pid,link_pid,node_pid)
);

/*==============================================================*/
/* Table: NI_CRF_LINK                                           */
/* CRFOBJECT����������link��                                    */
/*==============================================================*/
CREATE TABLE NI_CRF_LINK
(
	pid NUMBER(10) NOT NULL,
	link_pid NUMBER(10) NOT NULL PRIMARY KEY
);


create table NI_LINK_POLYGON
(
  TABLENAME VARCHAR2(25),
  ID        NUMBER(10),
  GEOM      SDO_GEOMETRY,
  NDIRECT   NUMBER,
  NCLOSED   NUMBER,
  LINKCOUNT NUMBER,
  PRIMARY KEY(tablename,ID)
);


create table NI_BORDERLINK
(
  TABLENAME VARCHAR2(25),
  LINK_PID        NUMBER(10),
  PRIMARY KEY(tablename,LINK_PID)
);


create table NI_RD_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_RW_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_AD_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_ZONE_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_LC_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_LU_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_CMBUILD_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_CMBLOCK_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

create table NI_CMROAD_LINESEG
(
  LINKPID   NUMBER(10),
  SEGNUM    NUMBER(4),
  GEOMETRY  SDO_GEOMETRY,
  primary key(LINKPID,SEGNUM) 
);

/*==============================================================*/
/* Table: ni_concat_onroad_node;                                */
/* ·�ϵ�ҽӵ�����LINK                                         */
/*==============================================================*/
create table NI_CONCAT_ONROAD_NODE
(
  master_id number(10),
  slave_id number(10),
  node_id NUMBER(10),
  primary key (master_id,slave_id)
);


/*==============================================================*/
/* Table: NI_RTIC_LINK                                         */
/*==============================================================*/
create table NI_RTIC_LINK 
(
   PID                  NUMBER(10),
   LINK_ID              NUMBER(10),
   CODE              VARCHAR2(10),
   PRIMARY KEY(pid,LINK_ID)
);

/*==============================================================*/
/* Table: NI_LLR_LINK                                           */
/*==============================================================*/
create table NI_LLR_LINK 
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(4),
   LINK_ID              NUMBER(10),
   TYPE                 VARCHAR2(50),
   PRIMARY KEY(pid,LINK_ID,TYPE)
);

comment on table NI_LLR_LINK is
'���߹�ϵLINK��';


CREATE TABLE SHD_BDYINTERSECT_LINK 
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10)
);
ALTER TABLE SHD_BDYINTERSECT_LINK NOLOGGING;
comment on table SHD_BDYINTERSECT_LINK is
'��������ཻ��LINK��,������һ�������Ƿ��ཻ';

/*==============================================================*/
/* Table: NI_TMC_LINK                                           */
/*==============================================================*/
create table NI_TMC_LINK 
(
   LINK_PID                  NUMBER(10),
   S_NODE                    NUMBER(10),
   E_NODE                    NUMBER(10),
   LOC_DIRECT                NUMBER(1),
   TMC_ID                    NUMBER(10),
   LINE_LOC                  NUMBER(5),
   PRIMARY KEY(LINK_PID,LOC_DIRECT,TMC_ID)
);
comment on table NI_TMC_LINK  is
'���ڼ��ͬһ·����λ�õ��LINK����״��';

/*==============================================================*/
/* Table: NI_LINK_LINK                                           */
/*==============================================================*/
create table NI_LINK_LINK
(
  FROM_LINK_PID NUMBER(10) not null,
  TO_LINK_PID   NUMBER(10) not null,
  TYPE          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
  FROM_NODE_PID NUMBER(10),
  MID_NODE_PID  NUMBER(10),
  END_NODE_PID  NUMBER(10),
  FROM_LINK_DIR NUMBER(1),
  TO_LINK_DIR   NUMBER(1),
  PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID,MID_NODE_PID)
);
comment on table NI_LINK_LINK  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_FORM                                          */
/*==============================================================*/
create table NI_LINK_FORM  (
   LINK_PID             NUMBER(10)                      not null,
   MULTI_DIGITIZED      NUMBER(1)  default 0,
   SPECIAL_TRAFFIC      NUMBER(1)  default 0,
   IC                   NUMBER(1)  default 0,
   JCT                  NUMBER(1)  default 0,
   SA                   NUMBER(1)  default 0,
   PA                   NUMBER(1)  default 0,
   CA                   NUMBER(1)  default 0,
   ZADAO                NUMBER(1)  default 0,
   BUXINGJIE            NUMBER(1)  default 0,
   TIANQIAO             NUMBER(1)  default 0,
   GONGJIAOCHE          NUMBER(1)  default 0,
   QIAO                 NUMBER(1)  default 0,
   SUIDAO               NUMBER(1)  default 0,
   HUANDAO              NUMBER(1)  default 0,
   FULU                 NUMBER(1)  default 0,
   DIAOTOUKOU           NUMBER(1)  default 0,
   POILIANJIE           NUMBER(1)  default 0,
   TIYOU                NUMBER(1)  default 0,
   TIZOU                NUMBER(1)  default 0,
   CHURUKOU             NUMBER(1)  default 0,
   SIDAO                NUMBER(1)  default 0,
   JIAOCHADIAN          NUMBER(1)  default 0,
   IMI                  NUMBER(1)  default 0,
   BENXIAN              NUMBER(1)   default 0,
   SPE_LINK1            NUMBER(1)   default 0
);

comment on table NI_LINK_FORM is
'���µ������������ֶ�';

alter table NI_LINK_FORM
   add constraint CKC_MULTI_DIGITIZED_NI_LINK_ check (MULTI_DIGITIZED is null or (MULTI_DIGITIZED in (0,1)));

alter table NI_LINK_FORM
   add constraint PK_NI_LINK_FORM primary key (LINK_PID);

create table NI_MESH_GRID
(
  GRID NUMBER(10,5),
  MARK NUMBER(1)
);
CREATE INDEX IDX_NI_MESH_GRID ON NI_MESH_GRID(MARK,GRID) PARALLEL;
comment on table NI_MESH_GRID is
'ͼ�������';


/*==============================================================*/
/* Table: NI_RTIC_LINK_LINK                                     */
/*==============================================================*/
create table NI_RTIC_LINK_LINK
(
   LINK1               NUMBER(10),
   LINK2                   NUMBER(10),
   CODE                  NUMBER(5),
   RANK                  NUMBER(1),
   MESH_ID               NUMBER(6),
   PRIMARY KEY(LINK1,LINK2,CODE)
);



CREATE TABLE SHD_IN_BUFFER_LINK 
(
   LINK_PID NUMBER(10),
   PRIMARY KEY(LINK_PID)
);
comment on table SHD_IN_BUFFER_LINK  is '���漸�α����а�������,�洢λ�����ڵ�link';


CREATE TABLE SHD_PARK_LINK 
(
   LINK_PID NUMBER(10),
   FACE_PID NUMBER(10)
);
comment on table SHD_PARK_LINK   is 'һ��node��λ��ͣ������,һ��λ���ڲ���link';

/*==============================================================*/
/* Table: NI_NODE_FORM                                          */
/*==============================================================*/
create table NI_NODE_FORM  (
   NODE_PID             NUMBER(10)                      not null,
   END_CA               NUMBER(1)  default 0,
   CRFO_NODE            NUMBER(1)  default 0,
   JCT                  NUMBER(1)  default 0
);

comment on table NI_NODE_FORM is
'���µ������������ֶ�';

alter table NI_NODE_FORM
   add constraint PK_NI_NODE_FORM primary key (NODE_PID);

/*==============================================================*/
/* Table: NI_UTURN_LINK                                         */
/*==============================================================*/
create table NI_UTURN_LINK (
   PID                  NUMBER(10)                      not null,
   NODE_ID              NUMBER(10)  default 0,
   LINK1                NUMBER(10)  default 0,
   LINK2                NUMBER(10)  default 0,
   ANGLE                NUMBER      default 0
);

comment on table NI_UTURN_LINK is
'��ͷ��LINK�ᴩ��';

/*==============================================================*/
/* Table: NI_CROSS_LINK_LINK                                         */
/*==============================================================*/
create table NI_CROSS_LINK_LINK(
   PID                  NUMBER(10)                      not null,
   NODE_ID              NUMBER(10)  default 0,
   LINK1                NUMBER(10)  default 0,
   LINK2                NUMBER(10)  default 0,
   ANGLE                NUMBER      default 0
);

comment on table NI_CROSS_LINK_LINK is
'·��LINK�ᴩ��';


/*==============================================================*/
/* Table: NN_LINK                                               */
/*==============================================================*/
create table NN_LINK
(
  LINK_PID      NUMBER(10) not null,
  S_NODE_PID    NUMBER(10) NOT NULL,
  E_NODE_PID    NUMBER(10) NOT NULL,
  CHAIN_LINKID  NUMBER     NOT NULL,
  primary key (LINK_PID,S_NODE_PID) 
);

comment on table NN_LINK is
'NI·��link����ÿһ����¼��ʾ��������ͨ�з����һ����·��˫���·��NINET�б���Ϊ������¼�������·����Ϊһ��';

/*==============================================================*/
/* Table: NI_MAINSIDE_LINK_LINK                                         */
/*==============================================================*/
create table NI_MAINSIDE_LINK_LINK(
   PID                  NUMBER(10)                      not null,
   NODE_ID              NUMBER(10)  default 0,
   LINK1                NUMBER(10)  default 0,         
   LINK2                NUMBER(10)  default 0,
   SIDE                 NUMBER(1)     default 0,
   IS_CHAIN             NUMBER(1)   default 0
);

comment on table NI_MAINSIDE_LINK_LINK is
'����·����·�ҽ�LINK������������·��·�����';


/*==============================================================*/
/* Table: NI_ZONE_kind                                               */
/*==============================================================*/
create table NI_ZONE_KIND
(
  FACE_ID       NUMBER(10) not null,
  kind          Number(1)  NOT NULL,
  REGION_ID      NUMBER(10) not null,
  geometry      sdo_geometry,
  primary key (FACE_ID)
);



/*==============================================================*/
/* Table: NI_CONN_CKRESULT                                             */
/*==============================================================*/
create table NI_CONN_CKRESULT
(
  RULEID     VARCHAR2(50),
  SUBITEM    VARCHAR2(200),
  GROUPID    NUMBER(10),
  LINK_PID   NUMBER(10),
  ISADJOIN   NUMBER(1),
  ISMAINCONN NUMBER(1)
);
comment on table NI_CONN_CKRESULT is
'��ͨ�Լ������';

create table NI_ADMIN_MESH
(
   PROVINCE_NAME VARCHAR2(50),
   ADMIN_CODE NUMBER(6),
   MESHNUM NUMBER(6) PRIMARY KEY
);

create table NI_CONN_DELREC
(
  RULEID  VARCHAR2(50),
  GROUPID NUMBER(10)
);


/*==============================================================*/
/* Table: NI_CROSS_INNERLINK                                        */
/*==============================================================*/
CREATE TABLE NI_CROSS_INNERLINK
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL,
    PRIMARY KEY(pid,link_pid)
);
comment on table NI_CROSS_INNERLINK is
'��ͨ�Լ�齻�����link����';


create table SHD_PT_PT_DISTANCE
(
  TABLENAME1 VARCHAR2(20),
  LINK_PID1  NUMBER(10),
  SEQ1       NUMBER(10),
  NPID1      NUMBER(10),
  TABLENAME2 VARCHAR2(20),
  LINK_PID2  NUMBER(10),
  SEQ2       NUMBER(10),
  NPID2      NUMBER(10),
  DIS        NUMBER(10,5),
  X          NUMBER(10,5),
  Y          NUMBER(10,5)
);
