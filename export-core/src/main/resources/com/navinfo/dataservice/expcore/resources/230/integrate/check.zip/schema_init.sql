whenever sqlerror exit failure
whenever oserror exit failure
set echo off
set timing on
@@common_tools_create.sql
@@pipeline_atab_create.sql
@@navi_basic_geom.pck
@@navi_geom.pck
@@glm_tool.pck
@@kbdb_data_tool.pck
@@schema_create.sql
@@tools_create.sql
exit