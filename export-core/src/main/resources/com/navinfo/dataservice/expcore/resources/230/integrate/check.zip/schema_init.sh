sqlplus -L $1 @/tmp/1.7.3/check/schema_init.sql
loadjava -user $1 -resolve -verbose /tmp/1.7.3/check/gdfTimeDomain.jar
