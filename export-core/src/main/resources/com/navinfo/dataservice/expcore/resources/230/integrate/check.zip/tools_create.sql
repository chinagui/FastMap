whenever sqlerror exit failure
whenever oserror exit failure
@@navi_log.pck
@@navi_task.pck
@@navi_parallel_job.pck
@@navi_val_executer.pck
@@navi_checkpreprocess.pck
@@navi_validation_geom.pck
@@glm_validation_tool.pck
@@nm_val_adapter.pck
@@glm_validation.pck
@@navi_val_rule.pck
@@navi_val_char_rule.pck
@@py_utils_word.pck
@@gdftime_util.pck
@@check_conn_result_transfer.pck