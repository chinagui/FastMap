whenever sqlerror continue;
drop table NI_CHAIN_SPTRAFFIC cascade constraints;
drop table NI_CHAIN_LINK_SPTRAFFIC cascade constraints;
drop table NI_CHAIN_ALINK_SPTRAFFIC cascade constraints;
drop table NI_CHAIN_HUANDAO cascade constraints;
drop table NI_CHAIN_LINK_HUANDAO cascade constraints;
drop table NI_CHAIN_ALINK_HUANDAO cascade constraints;
drop table NI_CHAIN_CRFR cascade constraints;
drop table NI_CHAIN_LINK_CRFR cascade constraints;
drop table NI_CHAIN_ALINK_CRFR cascade constraints;
drop table NI_CHAIN_JIAOCHAKOU cascade constraints;
drop table NI_CHAIN_LINK_JIAOCHAKOU cascade constraints;
drop table NI_CHAIN_ALINK_JIAOCHAKOU cascade constraints;
drop table NI_CHAIN_DIAOTOUKOU cascade constraints;
drop table NI_CHAIN_LINK_DIAOTOUKOU cascade constraints;
drop table NI_CHAIN_ALINK_DIAOTOUKOU cascade constraints;
drop table NI_CHAIN_JCT_CA cascade constraints;
drop table NI_CHAIN_LINK_JCT_CA cascade constraints;
drop table NI_CHAIN_ALINK_JCT_CA cascade constraints;
drop table NI_CHAIN_IC cascade constraints;
drop table NI_CHAIN_LINK_IC cascade constraints;
drop table NI_CHAIN_ALINK_IC cascade constraints;
drop table NI_CHAIN_JCT cascade constraints;
drop table NI_CHAIN_LINK_JCT cascade constraints;
drop table NI_CHAIN_ALINK_JCT cascade constraints;
drop table NI_CHAIN_SA cascade constraints;
drop table NI_CHAIN_LINK_SA cascade constraints;
drop table NI_CHAIN_ALINK_SA cascade constraints;
drop table NI_CHAIN_PA cascade constraints;
drop table NI_CHAIN_LINK_PA cascade constraints;
drop table NI_CHAIN_ALINK_PA cascade constraints;
drop table NI_CHAIN_TIZUO cascade constraints;
drop table NI_CHAIN_LINK_TIZUO cascade constraints;
drop table NI_CHAIN_ALINK_TIZUO cascade constraints;
drop table NI_CHAIN_TIYOU cascade constraints;
drop table NI_CHAIN_LINK_TIYOU cascade constraints;
drop table NI_CHAIN_ALINK_TIYOU cascade constraints;
drop table NI_CHAIN_M cascade constraints;
drop table NI_CHAIN_LINK_M cascade constraints;
drop table NI_CHAIN_ALINK_M cascade constraints;
drop table NI_CHAIN_ZADAO cascade constraints;
drop table NI_CHAIN_LINK_ZADAO cascade constraints;
drop table NI_CHAIN_ALINK_ZADAO cascade constraints;
drop table NI_CHAIN_CHURUKOU cascade constraints;
drop table NI_CHAIN_LINK_CHURUKOU cascade constraints;
drop table NI_CHAIN_ALINK_CHURUKOU cascade constraints;
drop table NI_LINK_LINK_SPTRAFFIC cascade constraints;
drop table NI_LINK_LINK_HUANDAO cascade constraints;
drop table NI_LINK_LINK_CRFR cascade constraints;
drop table NI_LINK_LINK_JIAOCHAKOU cascade constraints;
drop table NI_LINK_LINK_DIAOTOUKOU cascade constraints;
drop table NI_LINK_LINK_JCT_CA cascade constraints;
drop table NI_LINK_LINK_IC cascade constraints;
drop table NI_LINK_LINK_JCT cascade constraints;
drop table NI_LINK_LINK_SA cascade constraints;
drop table NI_LINK_LINK_PA cascade constraints;
drop table NI_LINK_LINK_TIZUO cascade constraints;
drop table NI_LINK_LINK_TIYOU cascade constraints;
drop table NI_LINK_LINK_CHURUKOU cascade constraints;
drop table NI_LINK_LINK_M cascade constraints;
drop table NI_LINK_LINK_ZADAO cascade constraints;

whenever sqlerror exit failure;
-------------���⽻ͨ����

/*==============================================================*/
/* Table: NI_CHAIN_SPTRAFFIC                                    */
/*==============================================================*/
create table NI_CHAIN_SPTRAFFIC
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_SPECIAL_TRAFFIC primary key (PID)
);

comment on table NI_CHAIN_SPTRAFFIC is
'���⽻ͨ����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_SPTRAFFIC                               */
/*==============================================================*/
create table NI_CHAIN_LINK_SPTRAFFIC
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_SPTRAFFIC
   add constraint FK_NI_CHAIN_LINK_SPTRAFFIC_RF foreign key (PID)
      references NI_CHAIN_SPTRAFFIC (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_SPTRAFFIC                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_SPTRAFFIC                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

-------------����

/*==============================================================*/
/* Table: NI_CHAIN_HUANDAO                                      */
/*==============================================================*/
create table NI_CHAIN_HUANDAO
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_HUANDAO primary key (PID)
);

comment on table NI_CHAIN_HUANDAO is
'��������·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_HUANDAO                               */
/*==============================================================*/
create table NI_CHAIN_LINK_HUANDAO
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_HUANDAO
   add constraint FK_NI_CHAIN_LINK_HUANDAO_RF foreign key (PID)
      references NI_CHAIN_HUANDAO (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_HUANDAO                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_HUANDAO                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);


-------------CRFR

/*==============================================================*/
/* Table: NI_CHAIN_CRFR                                      */
/*==============================================================*/
create table NI_CHAIN_CRFR
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_CRFR primary key (PID)
);

comment on table NI_CHAIN_CRFR is
'CRFR����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_CRFR                               */
/*==============================================================*/
create table NI_CHAIN_LINK_CRFR
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_CRFR
   add constraint FK_NI_CHAIN_LINK_CRFR_RF foreign key (PID)
      references NI_CHAIN_CRFR (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_CRFR                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_CRFR                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--------�������link

/*==============================================================*/
/* Table: NI_CHAIN_JIAOCHAKOU                                      */
/*==============================================================*/
create table NI_CHAIN_JIAOCHAKOU
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_JIAOCHAKOU primary key (PID)
);

comment on table NI_CHAIN_JIAOCHAKOU is
'JIAOCHAKOU����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_JIAOCHAKOU                               */
/*==============================================================*/
create table NI_CHAIN_LINK_JIAOCHAKOU
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_JIAOCHAKOU
   add constraint FK_NI_CHAIN_LINK_JIAOCHAKOU_RF foreign key (PID)
      references NI_CHAIN_JIAOCHAKOU (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_JIAOCHAKOU                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_JIAOCHAKOU                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--------��ͷ����link

/*==============================================================*/
/* Table: NI_CHAIN_DIAOTOUKOU                                      */
/*==============================================================*/
create table NI_CHAIN_DIAOTOUKOU
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_DIAOTOUKOU primary key (PID)
);

comment on table NI_CHAIN_DIAOTOUKOU is
'DIAOTOUKOU����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_DIAOTOUKOU                               */
/*==============================================================*/
create table NI_CHAIN_LINK_DIAOTOUKOU
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_DIAOTOUKOU
   add constraint FK_NI_CHAIN_LINK_DIAOTOUKOU_RF foreign key (PID)
      references NI_CHAIN_DIAOTOUKOU (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_DIAOTOUKOU                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_DIAOTOUKOU                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--------JCT+CA link

/*==============================================================*/
/* Table: NI_CHAIN_JCT_CA                                      */
/*==============================================================*/
create table NI_CHAIN_JCT_CA
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_JCT_CA primary key (PID)
);

comment on table NI_CHAIN_JCT_CA is
'JCT_CA����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_JCT_CA                               */
/*==============================================================*/
create table NI_CHAIN_LINK_JCT_CA
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_JCT_CA
   add constraint FK_NI_CHAIN_LINK_JCT_CA_RF foreign key (PID)
      references NI_CHAIN_JCT_CA (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_JCT_CA                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_JCT_CA                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--------IC link

/*==============================================================*/
/* Table: NI_CHAIN_IC                                      */
/*==============================================================*/
create table NI_CHAIN_IC
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_IC primary key (PID)
);

comment on table NI_CHAIN_IC is
'IC����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_IC                               */
/*==============================================================*/
create table NI_CHAIN_LINK_IC
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_IC
   add constraint FK_NI_CHAIN_LINK_IC_RF foreign key (PID)
      references NI_CHAIN_IC (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_IC                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_IC                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--------JCT link

/*==============================================================*/
/* Table: NI_CHAIN_JCT                                      */
/*==============================================================*/
create table NI_CHAIN_JCT
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_JCT primary key (PID)
);

comment on table NI_CHAIN_JCT is
'JCT����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_JCT                               */
/*==============================================================*/
create table NI_CHAIN_LINK_JCT
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_JCT
   add constraint FK_NI_CHAIN_LINK_JCT_RF foreign key (PID)
      references NI_CHAIN_JCT (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_JCT                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_JCT                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--------SA link
/*==============================================================*/
/* Table: NI_CHAIN_SA                                      */
/*==============================================================*/
create table NI_CHAIN_SA
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_SA primary key (PID)
);

comment on table NI_CHAIN_SA is
'SA����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_SA                               */
/*==============================================================*/
create table NI_CHAIN_LINK_SA
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_SA
   add constraint FK_NI_CHAIN_LINK_SA_RF foreign key (PID)
      references NI_CHAIN_SA (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_SA                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_SA                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);


--------PA link
/*==============================================================*/
/* Table: NI_CHAIN_PA                                      */
/*==============================================================*/
create table NI_CHAIN_PA
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_PARAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_PA primary key (PID)
);

comment on table NI_CHAIN_PA is
'PA����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_PA                               */
/*==============================================================*/
create table NI_CHAIN_LINK_PA
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_PA
   add constraint FK_NI_CHAIN_LINK_PA_RF foreign key (PID)
      references NI_CHAIN_PA (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_PA                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_PA                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--���� link
/*==============================================================*/
/* Table: NI_CHAIN_TIZUO                                      */
/*==============================================================*/
create table NI_CHAIN_TIZUO
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_TIZUORAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_TIZUO primary key (PID)
);

comment on table NI_CHAIN_TIZUO is
'TIZUO����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_TIZUO                               */
/*==============================================================*/
create table NI_CHAIN_LINK_TIZUO
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_TIZUO
   add constraint FK_NI_CHAIN_LINK_TIZUO_RF foreign key (PID)
      references NI_CHAIN_TIZUO (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_TIZUO                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_TIZUO                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--���� link
/*==============================================================*/
/* Table: NI_CHAIN_TIYOU                                      */
/*==============================================================*/
create table NI_CHAIN_TIYOU
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_TIYOURAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_TIYOU primary key (PID)
);
comment on table NI_CHAIN_TIYOU is
'TIYOU����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_TIYOU                               */
/*==============================================================*/
create table NI_CHAIN_LINK_TIYOU
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_TIYOU
   add constraint FK_NI_CHAIN_LINK_TIYOU_RF foreign key (PID)
      references NI_CHAIN_TIYOU (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_TIYOU                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_TIYOU                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--M���� link
/*==============================================================*/
/* Table: NI_CHAIN_M                                      */
/*==============================================================*/
create table NI_CHAIN_M
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_MRAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_M primary key (PID)
);

comment on table NI_CHAIN_M is
'M����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_M                               */
/*==============================================================*/
create table NI_CHAIN_LINK_M
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_M
   add constraint FK_NI_CHAIN_LINK_M_RF foreign key (PID)
      references NI_CHAIN_M (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_M                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_M                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--�ѵ����� link
/*==============================================================*/
/* Table: NI_CHAIN_ZADAO                                      */
/*==============================================================*/
create table NI_CHAIN_ZADAO
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_ZADAORAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_ZADAO primary key (PID)
);
comment on table NI_CHAIN_ZADAO is
'ZADAO����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_ZADAO                               */
/*==============================================================*/
create table NI_CHAIN_LINK_ZADAO
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_ZADAO
   add constraint FK_NI_CHAIN_LINK_ZADAO_RF foreign key (PID)
      references NI_CHAIN_ZADAO (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_ZADAO                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_ZADAO                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

--����·��������� link
/*==============================================================*/
/* Table: NI_CHAIN_CHURUKOU                                      */
/*==============================================================*/
create table NI_CHAIN_CHURUKOU
(
   PID                  NUMBER(10)           not null,
   S_NODE               NUMBER(10),
   E_NODE               NUMBER(10),
   DIR                  NUMBER(10) ,          
   length               number(5,1),
   V_CHURUKOURAMETER          NUMBER(10),
   GEOMETRY             SDO_GEOMETRY,
   constraint NI_CHAIN_CHURUKOU primary key (PID)
);
comment on table NI_CHAIN_CHURUKOU is
'CHURUKOU����·������';

/*==============================================================*/
/* Table: NI_CHAIN_LINK_CHURUKOU                               */
/*==============================================================*/
create table NI_CHAIN_LINK_CHURUKOU
(
   PID                  NUMBER(10),
   SEQ_NUM              NUMBER(3),
   LINK_ID              NUMBER(10)
);

alter table NI_CHAIN_LINK_CHURUKOU
   add constraint FK_NI_CHAIN_LINK_CHURUKOU_RF foreign key (PID)
      references NI_CHAIN_CHURUKOU (PID);
      

/*==============================================================*/
/* Table: NI_CHAIN_ALINK_CHURUKOU                              */
/* ·���ҽ�LINK��                                               */
/*==============================================================*/
CREATE TABLE NI_CHAIN_ALINK_CHURUKOU                                        
(
    pid NUMBER(10) NOT NULL,
    link_pid NUMBER(10) NOT NULL,
    node_pid NUMBER(10) NOT NULL,
    DIRECT CHAR(1) CHECK(DIRECT IN ('E','X','B')) NOT NULL
);

/*==============================================================*/
/* Table: NI_LINK_LINK_SPTRAFFIC                                */
/*==============================================================*/
create table NI_LINK_LINK_SPTRAFFIC 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_SPTRAFFIC  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_SPTRAFFIC.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_HUANDAO                                */
/*==============================================================*/
create table NI_LINK_LINK_HUANDAO 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_HUANDAO  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_HUANDAO.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_CRFR                                */
/*==============================================================*/
create table NI_LINK_LINK_CRFR 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_CRFR  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_CRFR.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_JIAOCHAKOU                                */
/*==============================================================*/
create table NI_LINK_LINK_JIAOCHAKOU 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_JIAOCHAKOU  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_JIAOCHAKOU.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_DIAOTOUKOU                                */
/*==============================================================*/
create table NI_LINK_LINK_DIAOTOUKOU 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_DIAOTOUKOU  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_DIAOTOUKOU.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_JCT_CA                                */
/*==============================================================*/
create table NI_LINK_LINK_JCT_CA 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_JCT_CA  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_JCT_CA.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_IC                                */
/*==============================================================*/
create table NI_LINK_LINK_IC 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_IC  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_IC.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_JCT                                */
/*==============================================================*/
create table NI_LINK_LINK_JCT 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_JCT  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_JCT.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_SA                                */
/*==============================================================*/
create table NI_LINK_LINK_SA 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_SA  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_SA.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_PA                                */
/*==============================================================*/
create table NI_LINK_LINK_PA 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_PA  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_PA.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_TIZUO                                */
/*==============================================================*/
create table NI_LINK_LINK_TIZUO 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_TIZUO  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_TIZUO.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_TIYOU                                */
/*==============================================================*/
create table NI_LINK_LINK_TIYOU 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_TIYOU  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_TIYOU.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_CHURUKOU                                */
/*==============================================================*/
create table NI_LINK_LINK_CHURUKOU 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_CHURUKOU  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_CHURUKOU.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_ZADAO                                */
/*==============================================================*/
create table NI_LINK_LINK_ZADAO 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_ZADAO  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_ZADAO.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

/*==============================================================*/
/* Table: NI_LINK_LINK_M                                */
/*==============================================================*/
create table NI_LINK_LINK_M 
(
   FROM_LINK_PID                 NUMBER(10),
   TO_LINK_PID                   NUMBER(10),
   TYPE                          VARCHAR2(1) CHECK(TYPE IN ('E','R')),
   PRIMARY KEY(FROM_LINK_PID,TO_LINK_PID)
);
comment on table NI_LINK_LINK_M  is
'LINK������';
COMMENT ON COLUMN NI_LINK_LINK_M.TYPE IS '����,E�ǿ�ͨ�У�R���н���';

exec pipeline_sdo.sdo_metadata_create('NI_CHAIN_CRFR', 'GEOMETRY');
