set timing on
whenever sqlerror continue;
drop sequence PIPELINE_VAL_EX_OBJECTID_SEQ;
drop sequence PIPELINE_VAL_EXCEPTION_ID_SEQ;
drop table PIPELINE_PROPERTY cascade constraints;
drop table PIPELINE_VAL_EXCEPTION_MESH cascade constraints;
drop table PIPELINE_VAL_EXCEPTION_OBJECT cascade constraints;
drop table PIPELINE_VAL_EXCEPTION cascade constraints;
drop package pipeline_validation_util;

whenever sqlerror exit failure;
CREATE SEQUENCE PIPELINE_VAL_EX_OBJECTID_SEQ
 INCREMENT BY 1 
 START WITH 1;
CREATE SEQUENCE PIPELINE_VAL_EXCEPTION_ID_SEQ 
 INCREMENT BY 1 
 START WITH 1;
 
CREATE TABLE PIPELINE_PROPERTY
(
  PROPERTY_NAME     VARCHAR2(100) NOT null,
  PROPERTY_VALUE    CLOB
);

CREATE TABLE PIPELINE_VAL_EXCEPTION (
       task_name            VARCHAR2(50),
       val_exception_id     NUMBER(10) NOT NULL,
       message              VARCHAR2(4000) NULL,
       timestamp            DATE NULL,
       user_id              VARCHAR2(50) NULL,
       rule_id              VARCHAR2(30) NOT NULL,
       shape 		    MDSYS.SDO_GEOMETRY NULL,
       object_id 	    NUMBER(10) NULL	,
       exception_flag       NUMBER(1) default 0
) nologging;

CREATE TABLE PIPELINE_VAL_EXCEPTION_MESH (
       task_name            VARCHAR2(50),
       val_exception_id     NUMBER(10) NOT NULL,
       mesh_id NUMBER(6),
       admin_id NUMBER(6)
) nologging;

COMMENT ON TABLE PIPELINE_VAL_EXCEPTION IS 'Validation results';

CREATE TABLE PIPELINE_VAL_EXCEPTION_OBJECT (
       task_name            VARCHAR2(50),
       val_exception_id     NUMBER(10) NOT NULL,
       sequence             NUMBER(10) NOT NULL,
       object_id            VARCHAR2(1000) NOT NULL,
       object_type          VARCHAR2(50) NULL,
       group_id             NUMBER(10) NOT NULL
) nologging;
@@pipeline_validation_util.pck
