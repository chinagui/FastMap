whenever sqlerror continue
whenever oserror exit failure
set echo off
set timing on
drop package common_util;
drop package pipeline_schema_utils;
drop package pipeline_sdo;
drop package pipeline_utils;
drop package bit_operations_util;
drop package bit_util;
begin
 EXECUTE IMMEDIATE 'PURGE RECYCLEBIN';
exception
  when others then
     null;
end; 
/
