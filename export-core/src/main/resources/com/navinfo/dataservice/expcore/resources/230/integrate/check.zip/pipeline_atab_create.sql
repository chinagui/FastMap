whenever sqlerror continue;
drop table NI_LINK_NODE cascade constraints;
drop table NI_VAL_PROPERTY cascade constraints;

whenever sqlerror exit failure;
create table NI_LINK_NODE
(
  LINK_ID      NUMBER(10) not null,
  TABLE_NAME    VARCHAR2(20) not null,
  NODE_ID      NUMBER(10),
  NODE_TYPE    CHAR(1) not null,
  NODE_SEQ     NUMBER(4),
  constraint NI_LINK_NODE_PK primary key (LINK_ID, TABLE_NAME, NODE_TYPE)
);

CREATE TABLE NI_VAL_PROPERTY
(
  PROPERTY_NAME     VARCHAR2(100) PRIMARY KEY,
  PROPERTY_DESC     VARCHAR2(1000),
  PROPERTY_VALUE    VARCHAR2(1000)
);

comment on table NI_VAL_PROPERTY is
'NIϵͳ���ò�����';

comment on column NI_VAL_PROPERTY.PROPERTY_DESC is
'NIϵͳ���ò�������';