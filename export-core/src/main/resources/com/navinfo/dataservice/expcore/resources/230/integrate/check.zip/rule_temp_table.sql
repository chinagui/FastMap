whenever sqlerror continue;

drop table T_GLM52038_1 cascade constraints;
drop table T_GLM52044_1 cascade constraints;
drop table T_GLM52045_1 cascade constraints;
drop table T_GLM21006_1 cascade constraints;
drop table T_GLM21007_1 cascade constraints;
drop table T_GLM21009_1 cascade constraints;
drop table T_GLM21010_1 cascade constraints;
drop table T_GLM22009_1 cascade constraints;
drop table T_GLM22010_1 cascade constraints;
drop table T_GLM03044_1 cascade constraints;
drop table T_GLM50015_1 cascade constraints;
drop table T_GLM52046_1 cascade constraints;
drop table T_GLM51014_1 cascade constraints;
drop table T_LC_SCOTOMA_NODE cascade constraints;
drop table T_ZONE_SCOTOMA_NODE cascade constraints;

whenever sqlerror exit failure;

/*==============================================================*/
/* Table: T_GLM52038_1					*/
/*==============================================================*/
CREATE TABLE T_GLM52038_1
(
   PID NUMBER(10),
   GEOMETRY MDSYS.SDO_GEOMETRY,
   PRIMARY KEY(PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM52038_1', 'GEOMETRY');
comment on table T_GLM52038_1 is '���α�BUFFER,���ڼ������link�Ĺ�ϵ';

/*==============================================================*/
/* Table: T_GLM52044_1					*/
/*==============================================================*/
CREATE TABLE T_GLM52044_1
(
   PID NUMBER(10),
   GEOMETRY MDSYS.SDO_GEOMETRY,
   PRIMARY KEY(PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM52044_1', 'GEOMETRY');
comment on table T_GLM52044_1 is '���α�BUFFER,���ڼ������link�Ĺ�ϵ';

/*==============================================================*/
/* Table: T_GLM52045_1					*/
/*==============================================================*/
CREATE TABLE T_GLM52045_1
(
   PID NUMBER(10),
   GEOMETRY MDSYS.SDO_GEOMETRY,
   PRIMARY KEY(PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM52045_1', 'GEOMETRY');
comment on table T_GLM52045_1 is '���α�BUFFER,���ڼ������link�Ĺ�ϵ';


CREATE TABLE T_GLM21006_1
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10),
   GEOMETRY  MDSYS.SDO_GEOMETRY,
   RTYPE     NUMBER(1)
);
comment on table T_GLM21006_1 is
'LINK�ཻ��������';

exec pipeline_sdo.sdo_metadata_create('T_GLM21006_1', 'GEOMETRY');

CREATE TABLE T_GLM21007_1
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10),
   GEOMETRY  MDSYS.SDO_GEOMETRY,
   RTYPE     NUMBER(1)
);
comment on table T_GLM21007_1 is
'LINK�ཻ��������';

exec pipeline_sdo.sdo_metadata_create('T_GLM21007_1', 'GEOMETRY');

CREATE TABLE T_GLM21009_1
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10),
   GEOMETRY  MDSYS.SDO_GEOMETRY,
   RTYPE     NUMBER(1)
);
comment on table T_GLM21009_1 is
'LINK�ཻ��������';

exec pipeline_sdo.sdo_metadata_create('T_GLM21009_1', 'GEOMETRY');

CREATE TABLE T_GLM21010_1
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10),
   GEOMETRY  MDSYS.SDO_GEOMETRY,
   RTYPE     NUMBER(1)
);
comment on table T_GLM21010_1 is
'LINK�ཻ��������';

exec pipeline_sdo.sdo_metadata_create('T_GLM21010_1', 'GEOMETRY');


CREATE TABLE T_GLM22009_1
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10),
   GEOMETRY  MDSYS.SDO_GEOMETRY,
   RTYPE     NUMBER(1)
);
comment on table T_GLM22009_1 is
'LINK�ཻ��������';

exec pipeline_sdo.sdo_metadata_create('T_GLM22009_1', 'GEOMETRY');



CREATE TABLE T_GLM22010_1
(
   TABLE_NAME1 VARCHAR2(30),
   LINK_PID1 NUMBER(10),
   TABLE_NAME2 VARCHAR2(30),
   LINK_PID2 NUMBER(10),
   GEOMETRY  MDSYS.SDO_GEOMETRY,
   RTYPE     NUMBER(1)
);
comment on table T_GLM22010_1 is
'LINK�ཻ��������';

exec pipeline_sdo.sdo_metadata_create('T_GLM22010_1', 'GEOMETRY');


create table T_GLM03044_1
(
   NODE_PID number(10),
   GEOMETRY mdsys.sdo_geometry,
   PRIMARY KEY(NODE_PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM03044_1', 'GEOMETRY');

create table T_GLM50015_1
(
   NODE_PID number(10),
   GEOMETRY mdsys.sdo_geometry,
   PRIMARY KEY(NODE_PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM50015_1', 'GEOMETRY');

create table T_GLM52046_1
(
   NODE_PID number(10),
   GEOMETRY mdsys.sdo_geometry,
   PRIMARY KEY(NODE_PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM52046_1', 'GEOMETRY');

create table T_GLM51014_1
(
   NODE_PID number(10),
   GEOMETRY mdsys.sdo_geometry,
   PRIMARY KEY(NODE_PID)
);
exec pipeline_sdo.sdo_metadata_create('T_GLM51014_1', 'GEOMETRY');


create table T_LC_SCOTOMA_NODE
(
   NODE_PID number(10),
   GEOMETRY mdsys.sdo_geometry,
   PRIMARY KEY(NODE_PID)
);
exec pipeline_sdo.sdo_metadata_create('T_LC_SCOTOMA_NODE', 'GEOMETRY');

create table T_ZONE_SCOTOMA_NODE
(
   NODE_PID number(10),
   GEOMETRY mdsys.sdo_geometry,
   PRIMARY KEY(NODE_PID)
);
exec pipeline_sdo.sdo_metadata_create('T_ZONE_SCOTOMA_NODE', 'GEOMETRY');

