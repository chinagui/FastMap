whenever sqlerror continue;
drop sequence NAVI$LOG_ID_SEQ;
DROP TABLE NAVI$TASK CASCADE CONSTRAINTS;
drop table NAVI$LOG cascade constraints;
drop table NAVI$JOB cascade constraints;
drop table NAVI$JOB_DEPENDS cascade constraints;
drop table NAVI$JOB_TYPE cascade constraints;
DROP TABLE NAVI$JOB_PARAM CASCADE CONSTRAINTS;

whenever sqlerror exit failure;

CREATE SEQUENCE NAVI$LOG_ID_SEQ
 INCREMENT BY 1 
 START WITH 1;

CREATE TABLE NAVI$TASK
(
  task_name VARCHAR2(50),
  app_name VARCHAR2(50),
  DESCRIPTION VARCHAR2(200),
  status VARCHAR2(10),
  start_time DATE,
  end_time DATE,
  owner VARCHAR2(50),
  message VARCHAR2(2000)
);

CREATE TABLE NAVI$LOG
(
  ID NUMBER(10),
  task_name varchar2(50),
  time DATE,
  type VARCHAR2(20),
  message CLOB
);

create table NAVI$JOB
(
  ID            NUMBER(10),
  CODE          VARCHAR2(100),
  TYPE          VARCHAR2(10),
  STATUS        VARCHAR2(10),
  TASK_NAME     VARCHAR2(50),
  QUEUENAME     VARCHAR2(50),
  TIMEOUT       NUMBER(5),
  ISORIGINALJOB NUMBER(1),
  START_TIME    DATE,
  END_TIME      DATE,
  PRIORITY      NUMBER(5),
  MESSAGE       VARCHAR2(2000)
);


create table NAVI$JOB_DEPENDS
(
  JOB_CODE   VARCHAR2(50),
  JOB_TYPE   VARCHAR2(50),
  D_JOB_CODE VARCHAR2(50),
  D_JOB_TYPE VARCHAR2(50),
  TASK_NAME  VARCHAR2(50)
);

create table NAVI$JOB_TYPE
(
  TASK_NAME VARCHAR2(50),
  JOB_TYPE  VARCHAR2(50),
  PROC_NAME VARCHAR2(50)
);

CREATE TABLE NAVI$JOB_PARAM
(
  NAME VARCHAR2(50),
  VALUE VARCHAR2(200),
  constraint PK_JOB_PARAM primary key (NAME)
);
