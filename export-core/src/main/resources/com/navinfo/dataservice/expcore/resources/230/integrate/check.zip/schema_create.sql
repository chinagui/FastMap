whenever sqlerror exit failure
whenever oserror exit failure
set echo off
set timing on
@@navisys_table_create.sql
@@rule_table_create.sql
@@char_table_create.sql
@@atab_create.sql
@@index_create.sql
@@rule_temp_table.sql
@@chain_table_create.sql
@@gdftime_check_type.sql