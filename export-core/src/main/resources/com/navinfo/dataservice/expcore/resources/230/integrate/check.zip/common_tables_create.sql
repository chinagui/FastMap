whenever sqlerror continue;
drop table PIPELINE_PROPERTY;
drop table PIPELINE_LOG;

whenever sqlerror exit failure;

CREATE TABLE PIPELINE_PROPERTY
(
  PROPERTY_NAME     VARCHAR2(100) NOT null,
  PROPERTY_VALUE    CLOB
);

CREATE TABLE PIPELINE_LOG
(
  time DATE,
  type NUMBER(2),
  msg  CLOB
);