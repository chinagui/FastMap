whenever oserror exit failure rollback
whenever sqlerror exit failure rollback
 delete from pipeline_property t;